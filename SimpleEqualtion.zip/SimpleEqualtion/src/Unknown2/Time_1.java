package Unknown2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.math.BigDecimal;

public class Time_1 extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private boolean Show = false;
	
	Container ct = getContentPane();
	TextArea t = new TextArea("�밴����һ����ʽ�������:\nax + by + c = 0\ndx + ey + f = 0",5,33);
	Label a = new Label("   a :");
	TextField getA = new TextField("",30);
	Label b = new Label("   b :");
	TextField getB = new TextField("",30);
	Label c = new Label("   c :");
	TextField getC = new TextField("",30);
	Label d = new Label("   d :");
	TextField getD = new TextField("",30);
	Label e = new Label("   e :");
	TextField getE = new TextField("",30);
	Label f = new Label("   f :");
	TextField getF = new TextField("",30);
	
	
	Label Result = new Label(" ���:");
	TextField result = new TextField("",28);
	TextArea cal = new TextArea("",12,33);
	
	public Time_1(){
		
		cal.setEditable(false);
		cal.setVisible(Show);
		getContentPane().setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		result.setEditable(false);
		t.setEditable(false);
		ct.add(t);
		ct.add(a);
		ct.add(getA);
		ct.add(b);
		ct.add(getB);
		ct.add(c);
		ct.add(getC);
		ct.add(d);
		ct.add(getD);
		ct.add(e);
		ct.add(getE);
		ct.add(f);
		ct.add(getF);
		ct.add(Result);
		ct.add(result);
		Button confirm = new Button("              ȷ��              ");
		Button calculate = new Button("             ��ʾ����             ");
		calculate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if (!Show) {
					Show = !Show;
					cal.setVisible(Show);
					setSize(300,600);
				} else {
					Show = !Show;
					cal.setVisible(Show);
					setSize(300,370);
				}
				
			}
		});
		confirm.addActionListener(this);
		ct.add(confirm);
		ct.add(calculate);
		ct.add(cal);
		
		setSize(300,370);
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		String aE = getA.getText();
		String bE = getB.getText();
		String cE = getC.getText();
		String dE = getD.getText();
		String eE = getE.getText();
		String fE = getF.getText();
		
		
		if (aE.equals("") || bE.equals("")) {
			result.setText("Error");
		} else {
//			System.out.println(aE + "\n" + bE);
			String res = "";
			BigDecimal mul = new BigDecimal(eE).multiply(new BigDecimal(bE));
			BigDecimal[] fuc1 = {mul.divide(new BigDecimal(bE),2,BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(aE)),mul,mul.divide(new BigDecimal(bE),2,BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(cE))};
//			for (BigDecimal x : fuc1) 
//				System.out.println(String.valueOf(x));
			BigDecimal[] fuc2 = {mul.divide(new BigDecimal(eE),2,BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(dE)),mul,mul.divide(new BigDecimal(eE),2,BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(fE))};
//			for (BigDecimal x : fuc2) 
//				System.out.println(String.valueOf(x));
			BigDecimal[] simp_equ = {fuc1[0].subtract(fuc2[0]),fuc1[2].subtract(fuc2[2])};
//			for (BigDecimal x : simp_equ) 
//				System.out.println(String.valueOf(x));
			BigDecimal x = (new BigDecimal(0).subtract(simp_equ[1])).divide(simp_equ[0],2,4);
			BigDecimal y = (BigDecimal.ZERO.subtract(fuc2[0].multiply(x).add(fuc2[2]))).divide(fuc2[1],2,4);
			
			res = "x = " + x + "    y = " + y ;
			String calc = aE + "x + (" + bE + ")y + (" + cE + ") = 0 ��\n" + dE + "x + (" + eE + ")y + (" + fE + ") = 0 �ֱ�� " + mul.divide(new BigDecimal(bE)) + "��" + mul.divide(new BigDecimal(eE)) +
					"\n\n" + fuc1[0] + "x + (" + fuc1[1] + ")y + (" + fuc1[2] + ") = 0\n" + fuc2[0] + "x + (" + fuc2[1] + ")y + (" + fuc2[2] + ") = 0\n\n" + fuc1[0] + "x + (" + fuc1[1] + ")y + (" + fuc1[2] + ") = 0 ��\n" + fuc2[0] + "x + (" + fuc2[1] + ")y + (" + fuc2[2] + ") = 0"
					+ " ��\n" + simp_equ[0] + "x + (" + simp_equ[1] + ") = 0\n��x = " + x + "\n��x = " + x + "����" + aE + "x + (" + bE + ")y + (" + cE + ") = 0 \n�� y = " + y; 
			
			
			
			cal.setText(calc);
			result.setText(res);
			
		}
		
	}

}
