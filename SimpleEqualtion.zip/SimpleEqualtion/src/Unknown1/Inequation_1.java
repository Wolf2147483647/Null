package Unknown1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.math.BigDecimal;

public class Inequation_1 extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	String[] arg = {"��","��","��","��"};
	private boolean Show = false;
	Container ct = getContentPane();
	TextArea t = new TextArea("�밴����һ����ʽ�������:\nax + b �� 0",5,33);
	Label a = new Label("   a :");
	TextField getA = new TextField("",30);
	Label b = new Label("   b :");
	TextField getB = new TextField("",30);
	Label Result = new Label(" ���:");
	TextField result = new TextField("",28);
	TextArea c = new TextArea("",3,33);
	JCheckBox c_s = new JCheckBox("��         ");
	JCheckBox c_b = new JCheckBox("��         ");
	JCheckBox c_se = new JCheckBox("��         ");
	JCheckBox c_be = new JCheckBox("��         ");
	private int MODE = 0;
	Button confirm = new Button("              ȷ��              ");
	
	public Inequation_1() {
		// TODO Auto-generated constructor stub
		Container ct = getContentPane();
		ct.setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		
		c_s.setSelected(true);
		c.setEditable(false);
		c.setVisible(Show);
		getContentPane().setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		result.setEditable(false);
		t.setEditable(false);
		ct.add(t);
		ct.add(c_s);
		ct.add(c_b);
		ct.add(c_se);
		ct.add(c_be);
		c_s.addActionListener(this);
		c_b.addActionListener(this);
		c_se.addActionListener(this);
		c_be.addActionListener(this);
		ct.add(a);
		ct.add(getA);
		ct.add(b);
		ct.add(getB);
		ct.add(Result);
		ct.add(result);
		
		
		Button calculate = new Button("             ��ʾ����             ");
		calculate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if (!Show) {
					Show = !Show;
					c.setVisible(Show);
					setSize(300,360);
				} else {
					Show = !Show;
					c.setVisible(Show);
					setSize(300,290);
				}
				
			}
		});
		confirm.addActionListener(this);
		ct.add(confirm);
		ct.add(calculate);
		ct.add(c);
		
		setSize(300,290);

		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==c_s) {
			c_b.setSelected(false);
			c_be.setSelected(false);
			c_se.setSelected(false);
			MODE = 0;
			c_s.setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b �� 0");
		} else if (e.getSource()==c_b) {
			c_s.setSelected(false);
			c_be.setSelected(false);
			c_se.setSelected(false);
			MODE = 1;
			c_b.setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b �� 0");
		} else if (e.getSource()==c_se) {
			c_b.setSelected(false);
			c_be.setSelected(false);
			c_s.setSelected(false);
			MODE = 2;
			c_se.setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b �� 0");
		} else if (e.getSource()==c_be) {
			c_b.setSelected(false);
			c_s.setSelected(false);
			c_se.setSelected(false);
			MODE = 3;
			c_be.setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b �� 0");
		} else if (e.getSource()==confirm) {
			String aE = getA.getText();
			String bE = getB.getText();
			
			if (aE.equals("") || bE.equals("")) {
				result.setText("Error");
			} else {
//				System.out.println(aE + "\n" + bE);
				String calc = aE + "x + (" + bE + ") " + arg[MODE] + " 0\n";
				calc = calc + aE + "x " + arg[MODE] + " (" + (new BigDecimal(0).subtract(new BigDecimal(bE))) + ")\n";
				BigDecimal res = new BigDecimal(0.0);
				res = res.subtract(new BigDecimal(bE));
				res = res.divide(new BigDecimal(aE),5,BigDecimal.ROUND_HALF_UP);
				calc = calc + "x " + arg[MODE] + " " + res ;
				c.setText(calc);
				
				result.setText("x " + arg[MODE] + " " + String.valueOf(res));
				
			}
			
		}
		
	}
	
}