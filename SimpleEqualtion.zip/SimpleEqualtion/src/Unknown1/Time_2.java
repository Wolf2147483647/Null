package Unknown1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.math.*;

public class Time_2 extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private boolean Show = false;
	private boolean M = true;
	
	Label ML = new Label("��ǰ����ģʽΪ:" + (M?"��ʽ��":"�䷽��"));
	Container ct = getContentPane();
	TextArea t = new TextArea("�밴����һ����ʽ�������:\nax" + (char)178 + " + bx + c = 0",3,33);
	Label a = new Label("   a :");
	TextField getA = new TextField("",30);
	Label b = new Label("   b :");
	TextField getB = new TextField("",30);
	Label c = new Label("   c :");
	TextField getC = new TextField("",30);
	Label Result = new Label(" ���:");
	TextField result = new TextField("",28);
	TextArea cal = new TextArea("",7,33);
	
	public Time_2(){
		
		ct.add(ML);
		cal.setEditable(false);
		cal.setVisible(Show);
		getContentPane().setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		result.setEditable(false);
		t.setEditable(false);
		ct.add(t);
		ct.add(a);
		ct.add(getA);
		ct.add(b);
		ct.add(getB);
		ct.add(c);
		ct.add(getC);
		ct.add(Result);
		ct.add(result);
		Button confirm = new Button("    ȷ��    ");
		Button calculate = new Button("   ��ʾ����   ");
		Button ModeChange = new Button("   �л�����ģʽ   ");
		ModeChange.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JFrame f = new JFrame("����");
				f.setLayout(new FlowLayout());
				f.setResizable(false);
				f.setVisible(true);
				Label l = new Label("�л�����ģʽ���ܻ���ʧ���㾫��");
				Label l1 = new Label("          ��ȷ��Ҫ�л���          ");
				Button y = new Button("ȷ��");
				y.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						// TODO Auto-generated method stub
						M=!M;
						ML.setText("��ǰ����ģʽΪ:" + (M?"��ʽ��":"�䷽��"));
						ML.repaint();
						f.setVisible(false);
					}
				});
				Label blank = new Label("               ");
				Button n = new Button("ȡ��");
				n.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						// TODO Auto-generated method stub
						f.setVisible(false);
					}
				});
				l.setSize(200,150);
				f.add(l);
				f.add(l1);
				f.add(y);
				f.add(blank);
				f.add(n);
				f.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
				f.setBounds(500,300,200,150);
				
			}
		});
//		ModeChange.setEnabled(false);
		calculate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if (!Show) {
					Show = !Show;
					cal.setVisible(Show);
					setSize(300,410);
				} else {
					Show = !Show;
					cal.setVisible(Show);
					setSize(300,280);
				}
				
			}
		});
		confirm.addActionListener(this);
		ct.add(confirm);
		ct.add(calculate);
		ct.add(ModeChange);
		ct.add(cal);
		
		setSize(300,280);
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		String aE = getA.getText();
		String bE = getB.getText();
		String cE = getC.getText();
		
		if (aE.equals("") || bE.equals("")) {
			result.setText("Error");
		} else {

			/**��ʽ*/
			if (M) {
				BigDecimal tmp1 = new BigDecimal(0.0);
				BigDecimal tmp2 = new BigDecimal(0.0);
				BigDecimal root = new BigDecimal(0.0);
				
				root = new BigDecimal(bE).pow(2).subtract(new BigDecimal(4).multiply(new BigDecimal(aE)).multiply(new BigDecimal(cE)));
				BigDecimal tmproot = root;
//				System.out.println(root);
				BigDecimal a = root;
				BigDecimal b = new BigDecimal(2.0);
				int p = 3;
				MathContext mc = new MathContext(p,RoundingMode.HALF_UP);
				if (a.compareTo(BigDecimal.ZERO)==0) {
					System.out.println(0);
				} else {
					BigDecimal x = root;
					for (int i=0;i<100;i++) {
						x=(x.add(a.divide(x,mc))).divide(b,mc);
					}	
//					System.out.println(x);
					root = x;
				}
				tmp2 = (new BigDecimal(0.0).subtract(new BigDecimal(bE)).subtract(root)).divide(new BigDecimal(2).multiply(new BigDecimal(aE)),2,4);
				tmp1 = (new BigDecimal(0.0).subtract(new BigDecimal(bE)).add(root)).divide(new BigDecimal(2).multiply(new BigDecimal(aE)),2,4);
//				res = res.subtract(new BigDecimal(bE));
//				res = res.divide(new BigDecimal(aE),5,BigDecimal.ROUND_HALF_UP);
				String calc = "x = {" + new BigDecimal(0).subtract(new BigDecimal(bE)) +"��"+(char)8730+"[(" + new BigDecimal(bE) + ")"+ (char)178 +"-4��" +new BigDecimal(aE) +"��" + new BigDecimal(cE) + "]}��(2��" + new BigDecimal(aE) + ")" + "\n" + 
						"x = {" + new BigDecimal(0).subtract(new BigDecimal(bE)) +"��"+(char)8730+ tmproot + "}��(2��" + new BigDecimal(aE) + ")" + "\n"
						+ "x = {" + new BigDecimal(0).subtract(new BigDecimal(bE)) +"��"+root +"}��" + new BigDecimal(2).multiply(new BigDecimal(aE)) + "\n" +
						"x1 = {" + new BigDecimal(0).subtract(new BigDecimal(bE)).add(root) +"}��" + new BigDecimal(2).multiply(new BigDecimal(aE)) + "\n" +
						"x2 = {" + new BigDecimal(0).subtract(new BigDecimal(bE)).subtract(root) +"}��" + new BigDecimal(2).multiply(new BigDecimal(aE));
				cal.setText(calc);
				
				result.setText("x1 = " + String.valueOf(tmp1) + "   x2 = " + String.valueOf(tmp2));
				if (tmproot.toString().toCharArray()[0]=='-') {
					result.setText("�˷�����ʵ����");
				}
			} else {
				/**�䷽*/ //ax^2 + bx + c = 0
				String str = "";
				BigDecimal a = new BigDecimal(aE);
				BigDecimal b = new BigDecimal(bE);
				BigDecimal c = new BigDecimal(cE);
				BigDecimal nb = b.divide(a);
				BigDecimal nc = c.divide(a);  //x^2 + nbx = -nc
				str = str + a + "x" + (char)178 + " + (" + b + ")x + (" + c + ") = 0" + "\n";
				str += "x" + (char)178 + " + ("  + nb + ")x = -(" + nc + ")\n";
				BigDecimal B_PLUS = nb.divide(new BigDecimal(2));
				BigDecimal B_TMP = B_PLUS.pow(2); //x^2 + nbx + B_TMP = B_TMP - nc
				str += "x" + (char)178 + " + ("  + nb + ")x + (" + B_TMP + ") = -(" + nc + ") + (" + B_TMP + ")\n";
				BigDecimal R_S = B_TMP.subtract(nc);   //x^2 + nbx + B_TMP = R_S
				str += "[x + (" + B_PLUS + ")]" + (char)178 + " = " + R_S + "\n";
				BigDecimal R_R = BigDecimal.ZERO; 
				//��������
				BigDecimal aR = R_S;
				BigDecimal bR = new BigDecimal(2.0);
				int p = 3;
				MathContext mc = new MathContext(p,RoundingMode.HALF_UP);
				if (aR.compareTo(BigDecimal.ZERO)==0) {
					System.out.println(0);
				} else {
					BigDecimal x = R_S;
					for (int i=0;i<100;i++) {
						x=(x.add(aR.divide(x,mc))).divide(bR,mc);
					}	
//					System.out.println(x);
					R_R = x;
				}
				//End : x + B_PLUS = R_R
				str += "x + (" + B_PLUS + ") = ��" + R_R + "\n";
				BigDecimal res1 = R_R.subtract(B_PLUS);
				BigDecimal res2 = BigDecimal.ZERO.subtract(R_R).subtract(B_PLUS);
				str += "x1 = " + R_R + " - (" + B_PLUS + ")\n";
				str += "x1 = -(" + R_R + ") - (" + B_PLUS + ")\n";
				result.setText("x1 = " + res1 + "   x2 = " + res2);
				cal.setText(str);
				
				
			}
			
		}
		
	}

}
