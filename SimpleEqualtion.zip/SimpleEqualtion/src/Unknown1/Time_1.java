package Unknown1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.math.BigDecimal;

public class Time_1 extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private boolean Show = false;
	
	Container ct = getContentPane();
	TextArea t = new TextArea("�밴����һ����ʽ�������:\nax + b = 0",5,33);
	Label a = new Label("   a :");
	TextField getA = new TextField("",30);
	Label b = new Label("   b :");
	TextField getB = new TextField("",30);
	Label Result = new Label(" ���:");
	TextField result = new TextField("",28);
	TextArea c = new TextArea("",3,33);
	
	public Time_1(){
		
		c.setEditable(false);
		c.setVisible(Show);
		getContentPane().setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		result.setEditable(false);
		t.setEditable(false);
		ct.add(t);
		ct.add(a);
		ct.add(getA);
		ct.add(b);
		ct.add(getB);
		ct.add(Result);
		ct.add(result);
		Button confirm = new Button("              ȷ��              ");
		Button calculate = new Button("             ��ʾ����             ");
		calculate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if (!Show) {
					Show = !Show;
					c.setVisible(Show);
					setSize(300,350);
				} else {
					Show = !Show;
					c.setVisible(Show);
					setSize(300,260);
				}
				
			}
		});
		confirm.addActionListener(this);
		ct.add(confirm);
		ct.add(calculate);
		ct.add(c);
		
		setSize(300,260);
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		String aE = getA.getText();
		String bE = getB.getText();
		
		if (aE.equals("") || bE.equals("")) {
			result.setText("Error");
		} else {
//			System.out.println(aE + "\n" + bE);
			String calc = aE + "x + " + bE + " = 0\n";
			calc = calc + aE + "x = " + (new BigDecimal(0).subtract(new BigDecimal(bE))) + "\n";
			BigDecimal res = new BigDecimal(0.0);
			res = res.subtract(new BigDecimal(bE));
			res = res.divide(new BigDecimal(aE),5,BigDecimal.ROUND_HALF_UP);
			calc = calc + "x = " + res ;
			c.setText(calc);
			
			result.setText(String.valueOf(res));
			
		}
		
	}

}
