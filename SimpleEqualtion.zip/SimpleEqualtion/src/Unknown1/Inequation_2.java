package Unknown1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.math.BigDecimal;

public class Inequation_2 extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	String[] arg = {"��","��","��","��"};
	private boolean Show = false;
	Container ct = getContentPane();
	TextArea t = new TextArea("�밴����һ����ʽ�������:\nax + b �� 0\ncx + d ��0",5,33);
	Label a = new Label("   a :");
	TextField getA = new TextField("",30);
	Label b = new Label("   b :");
	TextField getB = new TextField("",30);
	Label a1 = new Label("   c :");
	TextField getA1 = new TextField("",30);
	Label b1 = new Label("   d :");
	TextField getB1 = new TextField("",30);
	Label Result = new Label(" ���:");
	TextField result = new TextField("",28);
	TextArea c = new TextArea("",10,33);
	String str[] = {"��","��","��","��"};
	JCheckBox c1[] = {new JCheckBox(str[0]+"         "),new JCheckBox(str[1]+"         "),new JCheckBox(str[2]+"         "),new JCheckBox(str[3]+"         ")};
	JCheckBox c2[] = {new JCheckBox(str[0]+"         "),new JCheckBox(str[1]+"         "),new JCheckBox(str[2]+"         "),new JCheckBox(str[3]+"         ")};
	private int MODE1 = 0;
	private int MODE2 = 0;
	Button confirm = new Button("              ȷ��              ");
	
	public Inequation_2() {
		// TODO Auto-generated constructor stub
		Container ct = getContentPane();
		ct.setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		
		c1[0].setSelected(true);
		c2[0].setSelected(true);
		c.setEditable(false);
		c.setVisible(Show);
		getContentPane().setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		result.setEditable(false);
		t.setEditable(false);
		ct.add(t);
		for (int i = 0;i<c1.length;i++) {
			ct.add(c1[i]);
			c1[i].addActionListener(this);
		}
		for (int i = 0;i<c2.length;i++) {
			ct.add(c2[i]);
			c2[i].addActionListener(this);
		}
		ct.add(a);
		ct.add(getA);
		ct.add(b);
		ct.add(getB);
		ct.add(a1);
		ct.add(getA1);
		ct.add(b1);
		ct.add(getB1);
		ct.add(Result);
		ct.add(result);
		
		
		Button calculate = new Button("             ��ʾ����             ");
		calculate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if (!Show) {
					Show = !Show;
					c.setVisible(Show);
					setSize(300,560);
				} else {
					Show = !Show;
					c.setVisible(Show);
					setSize(300,380);
				}
				
			}
		});
		confirm.addActionListener(this);
		ct.add(confirm);
		ct.add(calculate);
		ct.add(c);
		
		setSize(300,380);

		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==c1[0]) {
			for (int i = 0 ;i<c1.length;i++) {
				if (c1[i]!=e.getSource()) {
					c1[i].setSelected(false);
				}
			}
			MODE1 = 0;
			c1[0].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==c1[1]) {
			for (int i = 0 ;i<c1.length;i++) {
				if (c1[i]!=e.getSource()) {
					c1[i].setSelected(false);
				}
			}
			MODE1 = 1;
			c1[1].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==c1[2]) {
			for (int i = 0 ;i<c1.length;i++) {
				if (c1[i]!=e.getSource()) {
					c1[i].setSelected(false);
				}
			}
			MODE1 = 2;
			c1[2].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==c1[3]) {
			for (int i = 0 ;i<c1.length;i++) {
				if (c1[i]!=e.getSource()) {
					c1[i].setSelected(false);
				}
			}
			MODE1 = 3;
			c1[3].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==c2[0]) {
			for (int i = 0 ;i<c2.length;i++) {
				if (c2[i]!=e.getSource()) {
					c2[i].setSelected(false);
				}
			}
			MODE2 = 0;
			c2[0].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==c2[1]) {
			for (int i = 0 ;i<c2.length;i++) {
				if (c2[i]!=e.getSource()) {
					c2[i].setSelected(false);
				}
			}
			MODE2 = 1;
			c2[1].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==c2[2]) {
			for (int i = 0 ;i<c2.length;i++) {
				if (c2[i]!=e.getSource()) {
					c2[i].setSelected(false);
				}
			}
			MODE2 = 2;
			c2[2].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==c2[3]) {
			for (int i = 0 ;i<c2.length;i++) {
				if (c2[i]!=e.getSource()) {
					c2[i].setSelected(false);
				}
			}
			MODE2 = 3;
			c2[3].setSelected(true);
			t.setText("�밴����һ����ʽ�������:\nax + b " + str[MODE1] + " 0\ncx + d " + str[MODE2] + "0");
		} else if (e.getSource()==confirm) {
			String aE = getA.getText();
			String bE = getB.getText();
			String cE = getA1.getText();
			String dE = getB1.getText();
			String calc = "";
			BigDecimal res[] = {new BigDecimal(0),BigDecimal.ZERO};
			
			if (aE.equals("") || bE.equals("")) {
				result.setText("Error");
			} else {
//				System.out.println(aE + "\n" + bE);
				calc = aE + "x + (" + bE + ") " + arg[MODE1] + " 0\n";
				calc = calc + aE + "x " + arg[MODE1] + " (" + (new BigDecimal(0).subtract(new BigDecimal(bE))) + ")\n";
				res[0] = new BigDecimal(0.0);
				res[0] = res[0].subtract(new BigDecimal(bE));
				res[0] = res[0].divide(new BigDecimal(aE),5,BigDecimal.ROUND_HALF_UP);
				calc = calc + "x " + arg[MODE1] + " " + res[0] ;
				c.setText(calc + "\n\n");
				
//				result.setText("x " + arg[MODE1] + " " + String.valueOf(res[0]));
				
			}
			if (aE.equals("") || bE.equals("")) {
				result.setText("Error");
			} else {
//				System.out.println(aE + "\n" + bE);
				calc = cE + "x + (" + dE + ") " + arg[MODE1] + " 0\n";
				calc = calc + cE + "x " + arg[MODE2] + " (" + (new BigDecimal(0).subtract(new BigDecimal(dE))) + ")\n";
				res[1] = new BigDecimal(0.0);
				res[1] = res[1].subtract(new BigDecimal(dE));
				res[1] = res[1].divide(new BigDecimal(cE),5,BigDecimal.ROUND_HALF_UP);
				calc = calc + "x " + arg[MODE2] + " " + res[1] ;
				c.append(calc);
				
//				result.setText("x " + arg[MODE2] + " " + String.valueOf(res[1]));
				
			}
//			System.out.println(res[0].subtract(res[1]).longValue());
			if (MODE1==MODE2) {
				if (MODE1==0) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[0])):"x �� " + (String.valueOf(res[1])));
				}
				if (MODE1==1) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[1])):"x �� " + (String.valueOf(res[0])));
				}
				if (MODE1==2) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[0])):"x �� " + (String.valueOf(res[1])));
				}
				if (MODE1==3) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[1])):"x �� " + (String.valueOf(res[0])));
				}
			} else if (Math.abs(MODE1-MODE2)==2) {
				if (MODE1==0) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[0])):"x �� " + (String.valueOf(res[1])));
				}
				if (MODE1==1) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[1])):"x �� " + (String.valueOf(res[0])));
				}
				if (MODE1==2) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[0])):"x �� " + (String.valueOf(res[1])));
				}
				if (MODE1==3) {
					result.setText((res[0].subtract(res[1]).longValue()<=0) ? "x �� " + (String.valueOf(res[1])):"x �� " + (String.valueOf(res[0])));
				}
			} else if (MODE1!=MODE2) {
//				System.out.println("DebugModeOn");
				if (res[0].subtract(res[1]).longValue()>=0 && MODE1!=MODE2) {
					result.setText("Error");
				} else if (res[0].subtract(res[1]).longValue()==0) {
					result.setText("x = " + res[0]);
				}
//				MODE2=MODE2-1;
			}
			
			
			
		}
		
	}
	
}