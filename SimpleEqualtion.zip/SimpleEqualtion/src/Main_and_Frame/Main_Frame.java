package Main_and_Frame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

public class Main_Frame extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Button bts[] = {new Button("��ͨ������"),new Button("һԪһ�η���"),new Button("һԪ���η���"),new Button("��Ԫһ�η�����"),new Button("һԪһ�β���ʽ"),new Button("һԪһ�β���ʽ��"),new Button("����")};
	
	Main_Frame () {
		
		Container ct = getContentPane();
		getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER));
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setResizable(false);
		Label l = new Label(/*"Type Selection"*/"����ѡ��");
		ct.add(l);
		
		for (int i = 0;i<bts.length;i++) {
			ct.add(bts[i]);
			bts[i].addActionListener(this);
		}
		for (int i = 5;i<bts.length;i++) {
			bts[i].setEnabled(false);
		}
		bts[bts.length-1].setEnabled(true);
		
		setSize(100,300);
		setLocation(200,100);
		
	}

	@SuppressWarnings("static-access")
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==bts[0]) {
			pkg.mainClass calc = new pkg.mainClass();
			String[] arg = {"0"};
			try {
				calc.main(arg);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (e.getSource()==bts[1]) {
			new Unknown1.Time_1();
		} else if (e.getSource()==bts[2]) {
			new Unknown1.Time_2();
		} else if (e.getSource()==bts[3]) {
			new Unknown2.Time_1();
		} else if (e.getSource()==bts[4]) {
			new Unknown1.Inequation_1();
		} else if (e.getSource()==bts[5]) {
			new Unknown1.Inequation_2();
		}
		if (e.getSource()==bts[bts.length-1]) {
			new S_pkg.S_Test();
		}
		
	}

}
