package pkg;
import java.awt.*;

import javax.swing.*;

public class updateInfo extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	updateInfo(int lan){
		Container ct = getContentPane();
		ct.setLayout(new FlowLayout());
		setVisible(true);
		String cn = "1.5 �汾������Ϣ��    \n\n        1.�����������ã���֧�����ġ�Ӣ�ģ�\n";/**    2.*/
		String en = "1.5 Update Information:\n\n    1.Add a language button that can choose lanuage between English and Chinese\n";
		JTextArea ta = new JTextArea("",7,20);
		if (lan==0) {
			ta.setText(cn);
		} else if (lan==1) {
			ta.setText(en);
		}
		ta.setEditable(false);
		ta.setLineWrap(true);
		ct.add(ta);
		setSize(250,200);
	}

}
