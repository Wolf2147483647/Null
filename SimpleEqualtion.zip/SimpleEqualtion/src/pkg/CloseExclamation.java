package pkg;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class CloseExclamation extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	CloseExclamation(int lan){
		Container ct = getContentPane();
		ct.setLayout(new FlowLayout());
		setSize(200,150);
		setVisible(true);
		String cn[] = {"          ��ȷ��Ҫ�رճ�����        ","��","��"};
		String en[] = {"     Are you sure to kill the program?   ","Yes","No"};
		Label l = new Label("");
		
		ct.add(l);
		l.setAlignment(0);
		
		Button y = new Button("");
		y.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					System.exit(0);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
		
		Button n = new Button("");
		n.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				setVisible(false);
			}
			
		});
		if (lan == 0) {
			l.setText(cn[0]);
			y.setLabel(cn[1]);
			n.setLabel(cn[2]);
		} else if (lan == 1) {
			l.setText(en[0]);
			y.setLabel(en[1]);
			n.setLabel(en[2]);
		}
		ct.add(y);
		ct.add(n);
	}
	
}
