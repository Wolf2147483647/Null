package pkg;

import java.io.IOException;

public class mainClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		if (args.length>0)
			new frame_calcButton(Integer.parseInt(args[0]));
		else
			new frame_calcButton(0);
//		new lang(Integer.parseInt(args[0]));
	}
	

}
