package pkg;

import java.awt.*;
import java.math.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.Arrays;

import javax.swing.*;

public class frame_calcButton extends JFrame implements ActionListener {
	
	private static final long serialVersionUID = 2541322635200385883L;
	private int calcType = -1;
	private int ltIndex;
	private BigDecimal Number1;
	private boolean err = false;
	private final int NULL = -1;
	private final int ADD = 0;
	private final int SUB = 1;
	private final int MUL = 2;
	private final int DIV = 3;
	private final int ROOT = 4;
	private final int T = 5;
	private String[] oNum = {"1","2","3","4","5","6","7","8","9","0"};
	private String[] calc = {"+","-","��","��","^",String.valueOf((char)8730)};
	private String[] cn = {"ɾ��","���","ȷ��","����","�ر�","������Ϣ","����"};
	private String[] en = {"Delete","Clear","Confirm","Reset","Close","Update Information","Language"};
	Button bts[] = new Button[oNum.length + calc.length + cn.length];
	JTextField jt=new JTextField("",20);
	frame_calcButton(int lan){
		//CalcTest_SubClass
		Container ct = getContentPane();
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setVisible(true);
		getContentPane().setLayout(new FlowLayout());

		jt.setEditable(false);
		jt.addFocusListener(new FocusListener() {

			@Override
			public void focusGained(FocusEvent arg0) {
				// TODO Auto-generated method stub
				if (jt.getText().equals("Error"))
					jt.setText("");
			}

			@Override
			public void focusLost(FocusEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
		ct.add(jt);
		
		int t = 0;
		/**Add NumberButton*/
		for (int i = 0;i<oNum.length;i++) {
			bts[i] = new Button(oNum[i]);
			ct.add(bts[i]);
			bts[i].addActionListener(this);
		}
		
		for (int i = oNum.length;i<(oNum.length+calc.length);i++) {
			bts[i] = new Button(calc[t]);
			ct.add(bts[i]);
			bts[i].addActionListener(this);
			t++;
		}
		
		t=0;
		
		for (int i = (calc.length + oNum.length);i<bts.length;i++) {
			bts[i] = new Button(lan==0?cn[t]:en[t]);
			t++;
		}
	
		Button Doc = new Button(" . ");
		ct.add(Doc);
		Doc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				jt.setText(jt.getText()+".");
			}
			
		});
		
		Button btD=new Button("");
		ct.add(btD);
		btD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (jt.getText().equals("Error"))
					jt.setText("");
				// TODO Auto-generated method stub;
				String str=jt.getText();
//				System.out.print(str+"\n");
				char chr[]=str.toCharArray();
//				System.out.println(chr);
				char[] chr1=Arrays.copyOf(chr, chr.length-1);
//				System.out.println(chr1);
				str=String.valueOf(chr1);
//				System.out.println(str);
				jt.setText(str);
			}
		
		});
		Button btE=new Button("");
		ct.add(btE);
		btE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub;
				jt.setText("");
			}
			
		});
		Button btC=new Button("");
		ct.add(btC);
		btC.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub;
				if (jt.getText().equals("Error"))
					jt.setText("");
				BigDecimal result = runcode(jt.getText());
				if (err)
					jt.setText("Error");
				else
					jt.setText(String.valueOf(result));
			}
			
		});
		Button reset = new Button("");
		ct.add(reset);
		reset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				calcType = NULL;
				ltIndex = 0;
				Number1 = new BigDecimal(0);
				err = false;
				jt.setText("");
			}
			
		});
		Button Close = new Button("");
		ct.add(Close);
		Close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new CloseExclamation(lan);
			}
			
		});
		Button info = new Button("");
		ct.add(info);
		info.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new updateInfo(lan);
			}
			
		});
		
		Button lang = new Button("");
		ct.add(lang);
		lang.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					new lang();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		});
		if (lan == 0) {
			btD.setLabel(cn[0]);
			btE.setLabel(cn[1]);
			btC.setLabel(cn[2]);
			reset.setLabel(cn[3]);
			Close.setLabel(cn[4]);
			info.setLabel(cn[5]);
			lang.setLabel(cn[6]);
		} else if (lan==1) {
			btD.setLabel(en[0]);
			btE.setLabel(en[1]);
			btC.setLabel(en[2]);
			reset.setLabel(en[3]);
			Close.setLabel(en[4]);
			info.setLabel(en[5]);
			lang.setLabel(en[6]);
		}
		setSize(250,200);
	}
	
	
	private BigDecimal calc(int type,int LIndex,BigDecimal num1,String FULLNum){
		
		BigDecimal result = new BigDecimal(0);
		char[] chr = FULLNum.toCharArray();
		char[] newChar = new char[chr.length-LIndex];
		for (int i = LIndex;i<chr.length;i++) {
			newChar[i-LIndex] = chr[i];
		}
		System.out.println(type + "\n" + LIndex + "\n" + num1 + "\n" + FULLNum + "\n" + String.valueOf(newChar));
		//System.out.println(FULLNum + "\n\n" + String.copyValueOf(chr)+"\n" +String.valueOf(newChar));
		switch (type) {
		
		case ADD:
			//System.out.println(newChar);
			result = num1.add(new BigDecimal(String.valueOf(newChar)));
			System.out.println(result);
			break;
		case SUB:
			//System.out.println(newChar);
			result = num1.subtract(new BigDecimal(String.valueOf(newChar)));
			break;
		case MUL:
			//System.out.println(newChar);
			result = num1.multiply(new BigDecimal(String.valueOf(newChar)));
			break;
		case DIV:
			//System.out.println(newChar);
			if (String.valueOf(newChar).equals("0"))
				err = true;
			else
				result = num1.divide(new BigDecimal(String.valueOf(newChar)),2,BigDecimal.ROUND_HALF_UP);
			break;
		case ROOT:
			result = num1.pow(Integer.parseInt(String.valueOf(newChar)));
			break;
		case T :
			String str = jt.getText();
			char[] c = str.toCharArray();
			char[] tmp = new char[c.length-1];
			for (int i = 1;i<c.length;i++) {
				tmp[i-1] = c[i];
			}
			c = null;
			BigDecimal a = new BigDecimal(String.valueOf(tmp));
			BigDecimal root = a;
//			System.out.println(a + "\n" + root);
			int p = 3;
			MathContext mc = new MathContext(p,RoundingMode.HALF_UP);
			if (a.compareTo(BigDecimal.ZERO)==0) {
				System.out.println(0);
			} else {
				BigDecimal x = root;
				for (int i=0;i<100;i++) {
					x=(x.add(a.divide(x,mc))).divide(new BigDecimal(2),mc);
				}
//				System.out.println(x);
				result = root = x;
			}
			break;
		default:
			break;
		}
		
		calcType = NULL;
		return result;
		
	}
	private BigDecimal runcode(String text) {
		BigDecimal result = calc(calcType,ltIndex,Number1,text);
		return result;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
		if (jt.getText().equals("Error"))
			jt.setText("");
		
		
		if (e.getSource() == bts[0]) {
			jt.setText(jt.getText()+"1");
		} else if (e.getSource() == bts[1]) {
			jt.setText(jt.getText()+"2");
		} else if (e.getSource() == bts[2]) {
			jt.setText(jt.getText()+"3");
		} else if (e.getSource() == bts[3]) {
			jt.setText(jt.getText()+"4");
		} else if (e.getSource() == bts[4]) {
			jt.setText(jt.getText()+"5");
		} else if (e.getSource() == bts[5]) {
			jt.setText(jt.getText()+"6");
		} else if (e.getSource() == bts[6]) {
			jt.setText(jt.getText()+"7");
		} else if (e.getSource() == bts[7]) {
			jt.setText(jt.getText()+"8");
		} else if (e.getSource() == bts[8]) {
			jt.setText(jt.getText()+"9");
		} else if (e.getSource() == bts[9]) {
			jt.setText(jt.getText()+"0");
		} else if (e.getSource() == bts[10]) {
			if (calcType!=NULL) {
				BigDecimal result = runcode(jt.getText());
				if (err)
					jt.setText("Error");
				else
					jt.setText(String.valueOf(result));
			}
			String str = jt.getText();
			calcType = ADD;
			int lastIndex = str.toCharArray().length + 1;
			BigDecimal numB1 = new BigDecimal(str);
			ltIndex = lastIndex;
			Number1 = numB1;
			jt.setText(jt.getText()+"+");
		} else if (e.getSource() == bts[11]) {

			if (calcType!=NULL) {
				BigDecimal result = runcode(jt.getText());
				if (err)
					jt.setText("Error");
				else
					jt.setText(String.valueOf(result));
			}
			String str = jt.getText();
			if (str.toCharArray().length==0) {
				jt.setText("-");
			} else {
				calcType = SUB;
				int lastIndex = str.toCharArray().length + 1;
				BigDecimal numB1 = new BigDecimal(str);
				ltIndex = lastIndex;
				Number1 = numB1;
				jt.setText(jt.getText()+"-");
			}
		} else if (e.getSource() == bts[12]) {

			if (calcType!=NULL && jt.getText().toCharArray()[0]!='-') {
				BigDecimal result = runcode(jt.getText());
				if (err)
					jt.setText("Error");
				else
					jt.setText(String.valueOf(result));
			}
			String str = jt.getText();
			calcType = MUL;
			int lastIndex = str.toCharArray().length + 1;
			BigDecimal numB1 = new BigDecimal(str);
			ltIndex = lastIndex;
			Number1 = numB1;
			jt.setText(jt.getText()+"��");
		} else if (e.getSource() == bts[13]) {

			if (calcType!=NULL) {
				BigDecimal result = runcode(jt.getText());
				if (err)
					jt.setText("Error");
				else
					jt.setText(String.valueOf(result));
			}
//			if (jt.getText().toCharArray()[0]!='-') {
			String str = jt.getText();
			calcType = DIV;
			int lastIndex = str.toCharArray().length + 1;
			BigDecimal numB1 = new BigDecimal(str);
			ltIndex = lastIndex;
			Number1 = numB1;
			jt.setText(jt.getText()+"��");
//			}
		} else if (e.getSource() == bts[14]) {

			if (calcType!=NULL && calcType != T) {
				BigDecimal result = runcode(jt.getText());
				if (err)
					jt.setText("Error");
				else
					jt.setText(String.valueOf(result));
			}
			String str = jt.getText();
			calcType = ROOT;
			int lastIndex = str.toCharArray().length + 1;
			BigDecimal numB1 = new BigDecimal(str);
			ltIndex = lastIndex;
			Number1 = numB1;
			jt.setText(jt.getText()+"^");
		} else if (e.getSource()==bts[15]) {
			if (calcType!=NULL) {
				BigDecimal result = runcode(jt.getText());
				if (err)
					jt.setText("Error");
				else
					jt.setText(String.valueOf(result));
			}
			calcType = T;
			jt.setText(jt.getText()+(char)8730);
		}
		
	}

}
