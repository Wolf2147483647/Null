package pkg;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.File;
import java.io.IOException;

public class lang extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	lang() throws IOException{
		Container ct = getContentPane();
		getContentPane().setLayout(new FlowLayout());
		setVisible(true);
		Button cn = new Button("����");
		Button en = new Button("English");
		ct.add(cn);
		ct.add(en);
		
		File f = new File("");
		String file = f.getCanonicalPath();
//		System.out.println(file);
		
		
		cn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					String cmd = ("\"" + file + "\\repaint.exe\" " + String.valueOf(0));
					System.out.println(cmd);
					Runtime.getRuntime().exec(cmd);
					System.exit(0);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		});
		
		en.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					String cmd = "\"" + file + "\\repaint.exe\" " + String.valueOf(1);
					Runtime.getRuntime().exec(cmd);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.exit(0);
			}
			
		});
		setSize(130,90);
//		File f = new File(this.getClass().getResource("/").getPath());
		
		
	}

}
