package S_pkg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class S_Test extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Container ct = getContentPane();
	TextArea t = new TextArea("���������ʽ(��֧�ָ���)",5,33);
	Button spe_c[] = {new Button("     " + String.valueOf((char)178) + "     "),new Button("     ��     "),new Button("     ��     "),new Button("    x    "),new Button("    y    ")};
	Label a = new Label("����ʽ:");
	TextField getA = new TextField("",27);
	Label Result = new Label(" ���:");
	TextField result = new TextField("",28);
	
	public S_Test () {
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLayout(new FlowLayout());
		setVisible(true);
		setResizable(false);
		ct.add(t);
		for (int i = 0;i<spe_c.length;i++) {
			ct.add(spe_c[i]);
			spe_c[i].addActionListener(this);
		}
		ct.add(a);
		ct.add(getA);
		ct.add(Result);
		ct.add(result);
		setSize(300,300);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==spe_c[0])
			getA.setText(getA.getText()+(char)178);
		if (e.getSource()==spe_c[1])
			getA.setText(getA.getText()+"��");
		if (e.getSource()==spe_c[2])
			getA.setText(getA.getText()+"��");
		
	}

}
